# Fusion Launcher

An Android home-screen launcher (Kotlin + Jetpack Compose) that blends the best of iOS and Samsung One UI.

## Build & install
1. Install Android Studio (Koala or newer) and open this folder (`FusionLauncher`).
2. Let Gradle sync (it downloads everything; first sync needs internet).
3. Enable Developer options + USB debugging on your phone, connect it, press **Run**.
4. Press the Home button and choose **Fusion Launcher → Always**
   (or Settings → Apps → Default apps → Home app).

Requires Android 8.0+ (API 26). Dynamic Material You colours on Android 12+.

## Features
| From iOS | From One UI |
|---|---|
| Today view (swipe right): clock, battery, flashlight, suggestions | App drawer (swipe up): alphabetical grid, search bar, A-Z fast scroller, pull down to close |
| App Library (last page): auto-sorted category cards, "+N" overflow | Edge panel: handle on the right edge, favourites + most-used apps |
| Spotlight-style search (swipe down): apps + web fallback | Configurable home grid (3–6 columns × 4–8 rows) |
| Squircle icons, glass dock, page dots | Icon size / labels / shape (squircle, rounded square, circle) |
| Long-press menu with app shortcuts | Hide apps, light/dark/system theme, haptics |

## Gestures
- Swipe up → app drawer · Swipe down → search
- Swipe right → Today view · Swipe past last home page → App Library
- Long-press empty space → launcher settings
- Long-press an app → shortcuts, move, add/remove Home/Dock, hide, app info, uninstall
- Right-edge handle → edge panel

## Known limits
- Layout is auto-flowed (use "Move earlier/later" in the long-press menu); there is no free drag-and-drop yet.
- No third-party widget hosting, folders, notification badges or double-tap-to-lock yet.
- App shortcuts in the long-press menu only appear once this is your default launcher.
- Edge handle can clash with the system back gesture on the right edge; tap the handle instead.

## Project layout
- `data/` – app list, categories, icon rendering, preferences
- `LauncherViewModel.kt` – state (home, dock, hidden, usage counts, settings)
- `ui/` – HomeScreen (pager + gestures), TodayPage, AppLibrary, AppDrawer, SearchOverlay, EdgePanel, ContextMenu, SettingsScreen

## Build without Android Studio (GitHub Actions)
1. Create a free GitHub account and a new repository.
2. Upload the *contents* of this folder (including the hidden `.github` folder) to the repo.
   If `.github/workflows/build.yml` didn't upload, use Add file → Create new file, type that path, and paste the file's contents.
3. Open the repo's **Actions** tab → "Build APK" → wait ~5 minutes for a green tick.
4. Open the run, download the **FusionLauncher-apk** artifact (a zip), unzip it and install `app-debug.apk` on your phone
   (allow "Install unknown apps" for your browser/file manager when asked).
