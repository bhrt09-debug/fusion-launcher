package com.fusionlauncher

import android.app.Application
import android.content.pm.ShortcutInfo
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fusionlauncher.data.AppCategory
import com.fusionlauncher.data.AppInfo
import com.fusionlauncher.data.AppRepository
import com.fusionlauncher.data.LauncherSettings
import com.fusionlauncher.data.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LauncherViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = AppRepository(application)
    private val prefs = Prefs(application)

    var apps by mutableStateOf<List<AppInfo>>(emptyList())
        private set
    var settings by mutableStateOf(prefs.loadSettings())
        private set
    var home by mutableStateOf(prefs.getList("home"))
        private set
    var dock by mutableStateOf(prefs.getList("dock"))
        private set
    var hidden by mutableStateOf(prefs.getSet("hidden"))
        private set
    var counts by mutableStateOf(prefs.allCounts())
        private set

    /** Bumped when the Home button is pressed so the UI can close overlays and snap to page 1. */
    var homeTick by mutableIntStateOf(0)
        private set

    private val appMap by derivedStateOf { apps.associateBy { it.packageName } }

    val visibleApps by derivedStateOf { apps.filter { it.packageName !in hidden } }
    val hiddenApps by derivedStateOf { apps.filter { it.packageName in hidden } }
    val homeApps by derivedStateOf {
        home.mapNotNull { appMap[it] }.filter { it.packageName !in hidden }
    }
    val dockApps by derivedStateOf {
        dock.mapNotNull { appMap[it] }.filter { it.packageName !in hidden }
    }
    val suggestions by derivedStateOf {
        visibleApps
            .filter { (counts[it.packageName] ?: 0) > 0 }
            .sortedByDescending { counts[it.packageName] ?: 0 }
            .take(8)
    }
    val categories: List<Pair<AppCategory, List<AppInfo>>> by derivedStateOf {
        AppCategory.values().mapNotNull { c ->
            visibleApps.filter { it.category == c }.takeIf { it.isNotEmpty() }?.let { c to it }
        }
    }

    init {
        refresh()
        repo.register { refresh() }
    }

    override fun onCleared() {
        repo.unregister()
        super.onCleared()
    }

    fun refresh() {
        viewModelScope.launch {
            val loaded = withContext(Dispatchers.Default) { repo.loadApps() }
            apps = loaded
            val known = loaded.map { it.packageName }.toSet()
            if (!prefs.initialized && loaded.isNotEmpty()) {
                val d = repo.defaultDock(loaded).take(5)
                val s = settings
                dock = d
                home = loaded.map { it.packageName }
                    .filter { it !in d }
                    .take(s.columns * s.rows * 2)
                prefs.initialized = true
                persist()
            } else {
                val h = home.filter { it in known }
                val dk = dock.filter { it in known }
                if (h != home || dk != dock) {
                    home = h
                    dock = dk
                    persist()
                }
            }
        }
    }

    private fun persist() {
        prefs.putList("home", home)
        prefs.putList("dock", dock)
        prefs.putList("hidden", hidden.toList())
    }

    // ---- launching -------------------------------------------------------------------------

    fun launch(app: AppInfo) {
        prefs.bumpLaunch(app.packageName)
        counts = prefs.allCounts()
        repo.launch(app)
    }

    fun goHome() {
        homeTick++
    }

    fun icon(app: AppInfo): ImageBitmap = repo.loadIcon(app)
    fun cachedIcon(app: AppInfo): ImageBitmap? = repo.cachedIcon(app.packageName)
    fun shortcuts(pkg: String): List<ShortcutInfo> = repo.shortcuts(pkg)
    fun startShortcut(s: ShortcutInfo) = repo.startShortcut(s)
    fun openAppInfo(pkg: String) = repo.openAppInfo(pkg)
    fun uninstall(pkg: String) = repo.uninstall(pkg)
    fun webSearch(q: String) = repo.webSearch(q)
    fun openHomeSettings() = repo.openDefaultLauncherSettings()

    // ---- home / dock editing ---------------------------------------------------------------

    fun addToHome(pkg: String) {
        if (pkg !in home) {
            home = home + pkg
            persist()
        }
    }

    fun removeFromHome(pkg: String) {
        home = home - pkg
        persist()
    }

    fun moveHome(pkg: String, delta: Int) {
        val i = home.indexOf(pkg)
        if (i < 0) return
        val j = (i + delta).coerceIn(0, home.size - 1)
        if (i == j) return
        val m = home.toMutableList()
        m.removeAt(i)
        m.add(j, pkg)
        home = m
        persist()
    }

    fun addToDock(pkg: String) {
        if (pkg in dock || dock.size >= 5) return
        dock = dock + pkg
        home = home - pkg
        persist()
    }

    fun removeFromDock(pkg: String) {
        dock = dock - pkg
        if (pkg !in home) home = home + pkg
        persist()
    }

    fun hide(pkg: String) {
        hidden = hidden + pkg
        home = home - pkg
        dock = dock - pkg
        persist()
    }

    fun unhide(pkg: String) {
        hidden = hidden - pkg
        persist()
    }

    fun updateSettings(s: LauncherSettings) {
        settings = s
        prefs.saveSettings(s)
    }

    // ---- search ----------------------------------------------------------------------------

    fun search(query: String): List<AppInfo> {
        val q = query.trim()
        if (q.isEmpty()) return emptyList()
        return visibleApps
            .filter { it.label.contains(q, ignoreCase = true) }
            .sortedWith(
                compareByDescending<AppInfo> { it.label.startsWith(q, ignoreCase = true) }
                    .thenBy { it.label.lowercase() }
            )
    }
}
