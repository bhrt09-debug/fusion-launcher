package com.fusionlauncher.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Process
import android.os.UserHandle
import android.provider.MediaStore
import android.provider.Settings
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

class AppRepository(private val context: Context) {
    private val pm: PackageManager = context.packageManager
    private val launcherApps: LauncherApps =
        context.getSystemService(Context.LAUNCHER_APPS_SERVICE) as LauncherApps
    private val iconCache = LruCache<String, ImageBitmap>(250)

    @Suppress("DEPRECATION")
    fun loadApps(): List<AppInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .asSequence()
            .filter { it.activityInfo.packageName != context.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { ri ->
                val ai = ri.activityInfo.applicationInfo
                AppInfo(
                    packageName = ri.activityInfo.packageName,
                    activityName = ri.activityInfo.name,
                    label = ri.loadLabel(pm).toString(),
                    category = categorize(ai),
                    isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                )
            }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    @Suppress("DEPRECATION")
    private fun categorize(ai: ApplicationInfo): AppCategory {
        val byCategory = when (ai.category) {
            ApplicationInfo.CATEGORY_GAME -> AppCategory.GAMES
            ApplicationInfo.CATEGORY_AUDIO,
            ApplicationInfo.CATEGORY_VIDEO,
            ApplicationInfo.CATEGORY_NEWS -> AppCategory.ENTERTAINMENT
            ApplicationInfo.CATEGORY_IMAGE -> AppCategory.PHOTO_VIDEO
            ApplicationInfo.CATEGORY_SOCIAL -> AppCategory.SOCIAL
            ApplicationInfo.CATEGORY_MAPS -> AppCategory.TRAVEL
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> AppCategory.PRODUCTIVITY
            else -> null
        }
        if (byCategory != null) return byCategory
        if ((ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0) return AppCategory.GAMES

        val p = ai.packageName.lowercase()
        fun has(vararg words: String) = words.any { p.contains(it) }
        return when {
            has("bank", "pay", "wallet", "finance", "money", "upi") -> AppCategory.FINANCE
            has("camera", "gallery", "photo", "video", "snapseed") -> AppCategory.PHOTO_VIDEO
            has("chat", "message", "mms", "whatsapp", "telegram", "instagram", "facebook",
                "twitter", "snapchat", "dialer", "contacts", "phone") -> AppCategory.SOCIAL
            has("maps", "uber", "travel", "flight", "airline", "irctc") -> AppCategory.TRAVEL
            has("music", "spotify", "youtube", "netflix", "hotstar", "podcast", "player") ->
                AppCategory.ENTERTAINMENT
            has("docs", "sheets", "office", "mail", "calendar", "drive", "notes", "keep",
                "slack", "teams") -> AppCategory.PRODUCTIVITY
            else -> AppCategory.UTILITIES
        }
    }

    fun loadIcon(app: AppInfo): ImageBitmap {
        iconCache.get(app.packageName)?.let { return it }
        val drawable = runCatching {
            pm.getActivityIcon(ComponentName(app.packageName, app.activityName))
        }.getOrElse { pm.defaultActivityIcon }
        val bmp = renderIcon(drawable).asImageBitmap()
        iconCache.put(app.packageName, bmp)
        return bmp
    }

    fun cachedIcon(pkg: String): ImageBitmap? = iconCache.get(pkg)

    /**
     * Adaptive icons are drawn full-bleed (background + foreground layers, cropped to the
     * 72dp visible area) so the launcher's own icon shape is applied instead of the OEM mask.
     */
    private fun renderIcon(d: Drawable): Bitmap {
        if (d is AdaptiveIconDrawable) {
            val full = 216 // 108dp @ 2x
            val bmp = Bitmap.createBitmap(full, full, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            d.background?.let { it.setBounds(0, 0, full, full); it.draw(canvas) }
            d.foreground?.let { it.setBounds(0, 0, full, full); it.draw(canvas) }
            val visible = 144 // 72dp @ 2x
            val inset = (full - visible) / 2
            return Bitmap.createBitmap(bmp, inset, inset, visible, visible)
        }
        return d.toBitmap(144, 144)
    }

    fun launch(app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(app.packageName, app.activityName))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        runCatching { context.startActivity(intent) }
    }

    fun openAppInfo(pkg: String) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }

    fun uninstall(pkg: String) {
        val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }

    fun webSearch(query: String) {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }

    fun openDefaultLauncherSettings() {
        val intent = Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }

    /** App shortcuts (long-press menu). Only available when this app is the default launcher. */
    fun shortcuts(pkg: String): List<ShortcutInfo> = runCatching {
        if (!launcherApps.hasShortcutHostPermission()) {
            emptyList()
        } else {
            val query = LauncherApps.ShortcutQuery()
                .setPackage(pkg)
                .setQueryFlags(
                    LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST or
                        LauncherApps.ShortcutQuery.FLAG_MATCH_PINNED
                )
            launcherApps.getShortcuts(query, Process.myUserHandle())
                ?.filter { it.isEnabled } ?: emptyList()
        }
    }.getOrDefault(emptyList())

    fun startShortcut(s: ShortcutInfo) {
        runCatching { launcherApps.startShortcut(s, null, null) }
    }

    @Suppress("DEPRECATION")
    fun defaultDock(apps: List<AppInfo>): List<String> {
        val known = apps.map { it.packageName }.toSet()
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_VIEW, Uri.parse("sms:")),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com"))
                .addCategory(Intent.CATEGORY_BROWSABLE),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        )
        return intents
            .mapNotNull { pm.resolveActivity(it, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName }
            .filter { it in known }
            .distinct()
    }

    /** Calls [onChange] whenever apps are installed, removed or updated. */
    fun register(onChange: () -> Unit) {
        val cb = object : LauncherApps.Callback() {
            override fun onPackageRemoved(packageName: String?, user: UserHandle?) = onChange()
            override fun onPackageAdded(packageName: String?, user: UserHandle?) = onChange()
            override fun onPackageChanged(packageName: String?, user: UserHandle?) = onChange()
            override fun onPackagesAvailable(
                packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean
            ) = onChange()

            override fun onPackagesUnavailable(
                packageNames: Array<out String>?, user: UserHandle?, replacing: Boolean
            ) = onChange()
        }
        callback = cb
        launcherApps.registerCallback(cb)
    }

    fun unregister() {
        callback?.let { launcherApps.unregisterCallback(it) }
        callback = null
    }

    private var callback: LauncherApps.Callback? = null
}
