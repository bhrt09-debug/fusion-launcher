package com.fusionlauncher.data

enum class AppCategory(val title: String) {
    SOCIAL("Social"),
    ENTERTAINMENT("Entertainment"),
    PRODUCTIVITY("Productivity"),
    PHOTO_VIDEO("Photo & Video"),
    GAMES("Games"),
    TRAVEL("Travel & Maps"),
    FINANCE("Finance"),
    UTILITIES("Utilities")
}

data class AppInfo(
    val packageName: String,
    val activityName: String,
    val label: String,
    val category: AppCategory,
    val isSystem: Boolean
)

enum class IconShape(val title: String) {
    SQUIRCLE("Squircle"),
    ROUNDED_SQUARE("Rounded square"),
    CIRCLE("Circle")
}

enum class ThemeMode(val title: String) {
    SYSTEM("System"),
    LIGHT("Light"),
    DARK("Dark")
}

data class LauncherSettings(
    val columns: Int = 4,
    val rows: Int = 6,
    val iconScale: Float = 1f,
    val showLabels: Boolean = true,
    val iconShape: IconShape = IconShape.SQUIRCLE,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val edgePanelEnabled: Boolean = true,
    val haptics: Boolean = true
)
