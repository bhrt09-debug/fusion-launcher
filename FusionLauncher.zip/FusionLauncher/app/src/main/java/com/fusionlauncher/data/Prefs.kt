package com.fusionlauncher.data

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    private val usage = context.getSharedPreferences("usage", Context.MODE_PRIVATE)

    var initialized: Boolean
        get() = sp.getBoolean("initialized", false)
        set(value) {
            sp.edit().putBoolean("initialized", value).apply()
        }

    fun loadSettings(): LauncherSettings {
        val d = LauncherSettings()
        return LauncherSettings(
            columns = sp.getInt("columns", d.columns),
            rows = sp.getInt("rows", d.rows),
            iconScale = sp.getFloat("iconScale", d.iconScale),
            showLabels = sp.getBoolean("labels", d.showLabels),
            iconShape = runCatching { IconShape.valueOf(sp.getString("shape", "") ?: "") }
                .getOrDefault(d.iconShape),
            themeMode = runCatching { ThemeMode.valueOf(sp.getString("theme", "") ?: "") }
                .getOrDefault(d.themeMode),
            edgePanelEnabled = sp.getBoolean("edge", d.edgePanelEnabled),
            haptics = sp.getBoolean("haptics", d.haptics)
        )
    }

    fun saveSettings(s: LauncherSettings) {
        sp.edit()
            .putInt("columns", s.columns)
            .putInt("rows", s.rows)
            .putFloat("iconScale", s.iconScale)
            .putBoolean("labels", s.showLabels)
            .putString("shape", s.iconShape.name)
            .putString("theme", s.themeMode.name)
            .putBoolean("edge", s.edgePanelEnabled)
            .putBoolean("haptics", s.haptics)
            .apply()
    }

    fun getList(key: String): List<String> =
        (sp.getString(key, "") ?: "").split("|").filter { it.isNotEmpty() }

    fun putList(key: String, list: List<String>) {
        sp.edit().putString(key, list.joinToString("|")).apply()
    }

    fun getSet(key: String): Set<String> = getList(key).toSet()

    fun bumpLaunch(pkg: String) {
        usage.edit().putInt(pkg, usage.getInt(pkg, 0) + 1).apply()
    }

    fun allCounts(): Map<String, Int> =
        usage.all.mapNotNull { (k, v) -> (v as? Int)?.let { k to it } }.toMap()
}
