package com.fusionlauncher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fusionlauncher.LauncherViewModel
import com.fusionlauncher.data.AppInfo
import kotlinx.coroutines.launch

private fun letterOf(label: String): Char {
    val c = label.firstOrNull()?.uppercaseChar() ?: '#'
    return if (c in 'A'..'Z') c else '#'
}

/**
 * One UI style app drawer: alphabetical grid, search bar on top, A-Z fast scroller on the right,
 * pull down (or tap Back / Home) to close.
 */
@Composable
fun AppDrawer(
    vm: LauncherViewModel,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    onClose: () -> Unit,
    onSearch: () -> Unit,
    onSettings: () -> Unit
) {
    val apps = vm.visibleApps
    val gridState = rememberLazyGridState()
    val scope = rememberCoroutineScope()

    val letters = remember(apps) { apps.map { letterOf(it.label) }.distinct().sorted() }
    val firstIndex = remember(apps) {
        letters.associateWith { l -> apps.indexOfFirst { letterOf(it.label) == l } }
    }

    val closeConnection = remember {
        object : NestedScrollConnection {
            var pulled = 0f
            override fun onPostScroll(
                consumed: Offset,
                available: Offset,
                source: NestedScrollSource
            ): Offset {
                if (source == NestedScrollSource.UserInput && available.y > 0f) {
                    pulled += available.y
                    if (pulled > 300f) {
                        pulled = 0f
                        onClose()
                    }
                } else if (consumed.y != 0f) {
                    pulled = 0f
                }
                return Offset.Zero
            }

            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                pulled = 0f
                return Velocity.Zero
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Glass.panel)
            .nestedScroll(closeConnection)
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            // drag handle: swipe down to close
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(24.dp)
                    .pointerInput(Unit) {
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = { total = 0f },
                            onDragEnd = { if (total > 60f) onClose() },
                            onDragCancel = { total = 0f },
                            onVerticalDrag = { _, dy -> total += dy }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier
                        .width(36.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(Glass.subtext.copy(alpha = 0.6f))
                )
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SearchPill(
                    hint = "Search apps",
                    background = Glass.field,
                    contentColor = Glass.subtext,
                    onClick = onSearch,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onSettings) {
                    Icon(Icons.Default.Settings, contentDescription = "Launcher settings", tint = Glass.text)
                }
            }
            LazyVerticalGrid(
                state = gridState,
                columns = GridCells.Fixed(vm.settings.columns),
                modifier = Modifier.fillMaxSize().padding(start = 8.dp, end = 28.dp, top = 8.dp)
            ) {
                items(apps, key = { it.packageName }) { app ->
                    AppCell(
                        app, vm,
                        onClick = { onLaunch(app) },
                        onLongClick = { onLongPress(app) },
                        modifier = Modifier.padding(vertical = 6.dp),
                        labelColor = Glass.text,
                        shadow = false
                    )
                }
            }
        }

        LetterBar(
            letters = letters,
            color = Glass.subtext,
            onSelect = { l ->
                val idx = firstIndex[l] ?: -1
                if (idx >= 0) scope.launch { gridState.scrollToItem(idx) }
            },
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 4.dp)
        )
    }
}

@Composable
private fun LetterBar(
    letters: List<Char>,
    color: Color,
    onSelect: (Char) -> Unit,
    modifier: Modifier = Modifier
) {
    var barHeight by remember { mutableIntStateOf(1) }
    fun pick(y: Float) {
        if (letters.isEmpty()) return
        val i = ((y / barHeight) * letters.size).toInt().coerceIn(0, letters.size - 1)
        onSelect(letters[i])
    }
    Column(
        modifier
            .fillMaxHeight(0.7f)
            .width(24.dp)
            .onSizeChanged { barHeight = it.height.coerceAtLeast(1) }
            .pointerInput(letters) { detectTapGestures { pick(it.y) } }
            .pointerInput(letters) {
                detectVerticalDragGestures(
                    onDragStart = { pick(it.y) },
                    onVerticalDrag = { change, _ -> pick(change.position.y) }
                )
            },
        verticalArrangement = Arrangement.SpaceEvenly,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        letters.forEach { Text(it.toString(), fontSize = 10.sp, color = color) }
    }
}
