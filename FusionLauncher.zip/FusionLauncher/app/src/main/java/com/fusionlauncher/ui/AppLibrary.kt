package com.fusionlauncher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.fusionlauncher.LauncherViewModel
import com.fusionlauncher.data.AppInfo

/** iOS App Library: every app auto-sorted into category cards. */
@Composable
fun AppLibraryPage(
    vm: LauncherViewModel,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    onSearch: () -> Unit
) {
    var expanded by remember { mutableStateOf<Pair<String, List<AppInfo>>?>(null) }

    val cards: List<Pair<String, List<AppInfo>>> = buildList {
        if (vm.suggestions.isNotEmpty()) add("Suggestions" to vm.suggestions)
        vm.categories.forEach { add(it.first.title to it.second) }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        SearchPill(
            hint = "App Library",
            background = HomeSurface,
            contentColor = Color.White.copy(alpha = 0.85f),
            onClick = onSearch,
            modifier = Modifier.padding(top = 8.dp)
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(vertical = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(cards, key = { it.first }) { card ->
                CategoryCard(
                    title = card.first,
                    list = card.second,
                    vm = vm,
                    onLaunch = onLaunch,
                    onLongPress = onLongPress,
                    onOpenAll = { expanded = card }
                )
            }
        }
    }

    expanded?.let { (title, list) ->
        Dialog(onDismissRequest = { expanded = null }) {
            Column(
                Modifier
                    .clip(RoundedCornerShape(28.dp))
                    .background(Glass.panel)
                    .padding(16.dp)
            ) {
                Text(title, color = Glass.text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                LazyVerticalGrid(
                    columns = GridCells.Fixed(4),
                    modifier = Modifier.heightIn(max = 480.dp).padding(top = 12.dp)
                ) {
                    items(list, key = { it.packageName }) { app ->
                        AppCell(
                            app, vm,
                            onClick = { expanded = null; onLaunch(app) },
                            onLongClick = { expanded = null; onLongPress(app) },
                            labelColor = Glass.text,
                            shadow = false
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryCard(
    title: String,
    list: List<AppInfo>,
    vm: LauncherViewModel,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    onOpenAll: () -> Unit
) {
    val overflow = list.size > 4
    val shown = if (overflow) list.take(3) else list

    Column {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(HomeSurface)
                .padding(8.dp)
        ) {
            for (row in 0..1) {
                Row(Modifier.fillMaxWidth()) {
                    for (col in 0..1) {
                        val idx = row * 2 + col
                        Box(
                            Modifier.weight(1f).aspectRatio(1f).padding(5.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            val app = shown.getOrNull(idx)
                            when {
                                app != null -> AppIcon(
                                    app, vm,
                                    Modifier
                                        .fillMaxSize()
                                        .appClickable(vm, { onLaunch(app) }, { onLongPress(app) })
                                )
                                idx == 3 && overflow -> Box(
                                    Modifier
                                        .fillMaxSize()
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(Color.White.copy(alpha = 0.2f))
                                        .clickable(onClick = onOpenAll),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "+${list.size - 3}",
                                        color = Color.White,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        Text(
            title,
            color = Color.White,
            fontSize = 12.sp,
            modifier = Modifier.padding(start = 6.dp, top = 4.dp)
        )
    }
}
