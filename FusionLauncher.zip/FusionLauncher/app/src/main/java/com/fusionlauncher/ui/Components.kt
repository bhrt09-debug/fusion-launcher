package com.fusionlauncher.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fusionlauncher.LauncherViewModel
import com.fusionlauncher.data.AppInfo
import com.fusionlauncher.data.IconShape
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sin

/** iOS-style continuous-corner "squircle" (superellipse, n = 4). */
object SquircleShape : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val a = size.width / 2f
        val b = size.height / 2f
        val steps = 90
        val path = Path()
        for (i in 0..steps) {
            val t = 2.0 * PI * i / steps
            val c = cos(t)
            val s = sin(t)
            val x = a + a * sign(c) * abs(c).pow(0.5)
            val y = b + b * sign(s) * abs(s).pow(0.5)
            if (i == 0) path.moveTo(x.toFloat(), y.toFloat()) else path.lineTo(x.toFloat(), y.toFloat())
        }
        path.close()
        return Outline.Generic(path)
    }
}

fun IconShape.toShape(): Shape = when (this) {
    IconShape.SQUIRCLE -> SquircleShape
    IconShape.ROUNDED_SQUARE -> RoundedCornerShape(percent = 24)
    IconShape.CIRCLE -> CircleShape
}

@Composable
fun AppIcon(app: AppInfo, vm: LauncherViewModel, modifier: Modifier = Modifier) {
    val bmp by produceState<ImageBitmap?>(vm.cachedIcon(app), app.packageName) {
        if (value == null) value = withContext(Dispatchers.Default) { vm.icon(app) }
    }
    val shape = vm.settings.iconShape.toShape()
    val b = bmp
    if (b != null) {
        Image(bitmap = b, contentDescription = app.label, modifier = modifier.clip(shape))
    } else {
        Box(modifier.clip(shape).background(Color.White.copy(alpha = 0.15f)))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modifier.appClickable(vm: LauncherViewModel, onClick: () -> Unit, onLongClick: () -> Unit): Modifier {
    val haptic = LocalHapticFeedback.current
    val haptics = vm.settings.haptics
    return this.combinedClickable(
        onClick = onClick,
        onLongClick = {
            if (haptics) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            onLongClick()
        }
    )
}

private val LabelShadow = Shadow(Color.Black.copy(alpha = 0.55f), blurRadius = 4f)

@Composable
fun AppCell(
    app: AppInfo,
    vm: LauncherViewModel,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    modifier: Modifier = Modifier,
    labelColor: Color = Color.White,
    shadow: Boolean = true
) {
    val s = vm.settings
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .appClickable(vm, onClick, onLongClick)
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AppIcon(app, vm, Modifier.size((56 * s.iconScale).dp))
        if (s.showLabels) {
            Spacer(Modifier.size(4.dp))
            Text(
                text = app.label,
                color = labelColor,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                style = if (shadow) TextStyle(shadow = LabelShadow) else TextStyle.Default
            )
        }
    }
}

@Composable
fun SearchPill(
    hint: String,
    background: Color,
    contentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(background)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Start
    ) {
        Icon(Icons.Default.Search, contentDescription = null, tint = contentColor)
        Spacer(Modifier.width(8.dp))
        Text(hint, color = contentColor)
    }
}

@Composable
fun PageDots(count: Int, current: Int, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.Center
    ) {
        repeat(count) { i ->
            Box(
                Modifier
                    .padding(horizontal = 3.dp)
                    .size(if (i == current) 8.dp else 6.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = if (i == current) 0.95f else 0.4f))
            )
        }
    }
}
