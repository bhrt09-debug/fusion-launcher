package com.fusionlauncher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.fusionlauncher.LauncherViewModel
import com.fusionlauncher.data.AppInfo

/** Long-press menu: app shortcuts (when this is the default launcher) plus home/dock actions. */
@Composable
fun AppContextMenu(app: AppInfo, vm: LauncherViewModel, onDismiss: () -> Unit) {
    val pkg = app.packageName
    val shortcuts = remember(pkg) { vm.shortcuts(pkg).take(4) }
    val inHome = pkg in vm.home
    val inDock = pkg in vm.dock

    fun act(block: () -> Unit): () -> Unit = {
        block()
        onDismiss()
    }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .widthIn(max = 320.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(Glass.panel)
                .padding(vertical = 12.dp)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AppIcon(app, vm, Modifier.size(40.dp))
                Spacer(Modifier.width(12.dp))
                Text(app.label, color = Glass.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            }
            HorizontalDivider(color = Glass.subtext.copy(alpha = 0.3f))

            if (shortcuts.isNotEmpty()) {
                shortcuts.forEach { sc ->
                    MenuRow(sc.shortLabel?.toString() ?: sc.id, onClick = act { vm.startShortcut(sc) })
                }
                HorizontalDivider(color = Glass.subtext.copy(alpha = 0.3f))
            }

            if (inHome) {
                MenuRow("Move earlier", onClick = act { vm.moveHome(pkg, -1) })
                MenuRow("Move later", onClick = act { vm.moveHome(pkg, 1) })
                MenuRow("Remove from Home", onClick = act { vm.removeFromHome(pkg) })
            } else if (!inDock) {
                MenuRow("Add to Home", onClick = act { vm.addToHome(pkg) })
            }
            if (inDock) {
                MenuRow("Remove from Dock", onClick = act { vm.removeFromDock(pkg) })
            } else if (vm.dock.size < 5) {
                MenuRow("Add to Dock", onClick = act { vm.addToDock(pkg) })
            }
            MenuRow("Hide app", onClick = act { vm.hide(pkg) })
            MenuRow("App info", onClick = act { vm.openAppInfo(pkg) })
            if (!app.isSystem) {
                MenuRow("Uninstall", color = Color(0xFFFF453A), onClick = act { vm.uninstall(pkg) })
            }
        }
    }
}

@Composable
private fun MenuRow(label: String, onClick: () -> Unit, color: Color = Glass.text) {
    Text(
        label,
        color = color,
        fontSize = 16.sp,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp)
    )
}
