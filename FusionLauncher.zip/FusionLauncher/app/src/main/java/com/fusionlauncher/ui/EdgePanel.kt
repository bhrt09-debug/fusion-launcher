package com.fusionlauncher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fusionlauncher.LauncherViewModel
import com.fusionlauncher.data.AppInfo

/** The thin handle on the right edge (One UI "Edge panel"): swipe left or tap to open. */
@Composable
fun EdgeHandle(onOpen: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .width(22.dp)
            .height(120.dp)
            .pointerInput(Unit) {
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -40f) onOpen() },
                    onDragCancel = { total = 0f },
                    onHorizontalDrag = { _, dx -> total += dx }
                )
            }
            .pointerInput(Unit) { detectTapGestures { onOpen() } },
        contentAlignment = Alignment.CenterEnd
    ) {
        Box(
            Modifier
                .width(4.dp)
                .height(64.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Color.White.copy(alpha = 0.45f))
        )
    }
}

/** Favourites + most-used apps in a slide-in column, reachable from any screen. */
@Composable
fun EdgePanel(
    vm: LauncherViewModel,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    onClose: () -> Unit
) {
    val favourites = (vm.dockApps + vm.suggestions).distinctBy { it.packageName }.take(10)

    Row(Modifier.fillMaxSize()) {
        Box(
            Modifier
                .weight(1f)
                .fillMaxHeight()
                .background(Color.Black.copy(alpha = 0.25f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onClose
                )
        )
        Box(
            Modifier
                .width(104.dp)
                .fillMaxHeight()
                .clip(RoundedCornerShape(topStart = 28.dp, bottomStart = 28.dp))
                .background(Glass.panel)
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            LazyColumn(
                Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 16.dp)
            ) {
                item {
                    Text(
                        "Apps",
                        color = Glass.subtext,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
                if (favourites.isEmpty()) {
                    item {
                        Text(
                            "Open a few apps and they will appear here.",
                            color = Glass.subtext,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    }
                }
                items(favourites, key = { it.packageName }) { app ->
                    AppCell(
                        app, vm,
                        onClick = { onLaunch(app) },
                        onLongClick = { onLongPress(app) },
                        modifier = Modifier.padding(vertical = 4.dp),
                        labelColor = Glass.text,
                        shadow = false
                    )
                }
            }
        }
    }
}
