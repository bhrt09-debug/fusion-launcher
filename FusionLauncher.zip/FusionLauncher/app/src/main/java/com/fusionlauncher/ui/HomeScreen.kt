package com.fusionlauncher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fusionlauncher.LauncherViewModel
import com.fusionlauncher.data.AppInfo
import kotlinx.coroutines.launch
import kotlin.math.ceil
import kotlin.math.max

private enum class Overlay { NONE, DRAWER, SEARCH, SETTINGS }

/**
 * Page order:  [Today view] [Home 1..N] [App Library]
 * Gestures:    swipe up = app drawer, swipe down = search, long-press empty space = settings,
 *              handle on the right edge = edge panel.
 */
@Composable
fun LauncherRoot(vm: LauncherViewModel) {
    var overlay by remember { mutableStateOf(Overlay.NONE) }
    var menuApp by remember { mutableStateOf<AppInfo?>(null) }
    var edgeOpen by remember { mutableStateOf(false) }

    val s = vm.settings
    val perPage = s.columns * s.rows
    val homePages = max(1, ceil(vm.homeApps.size / perPage.toFloat()).toInt())
    val pageCount = homePages + 2
    val libraryPage = pageCount - 1

    val pager = rememberPagerState(initialPage = 1) { pageCount }
    val scope = rememberCoroutineScope()

    LaunchedEffect(vm.homeTick) {
        if (vm.homeTick > 0) {
            overlay = Overlay.NONE
            menuApp = null
            edgeOpen = false
            pager.animateScrollToPage(1)
        }
    }

    val onLaunch: (AppInfo) -> Unit = { app ->
        overlay = Overlay.NONE
        edgeOpen = false
        vm.launch(app)
    }
    val onLongPress: (AppInfo) -> Unit = { app -> menuApp = app }

    BackHandler(enabled = overlay != Overlay.NONE || edgeOpen || pager.currentPage != 1) {
        when {
            edgeOpen -> edgeOpen = false
            overlay != Overlay.NONE -> overlay = Overlay.NONE
            else -> scope.launch { pager.animateScrollToPage(1) }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        if (total < -120f) overlay = Overlay.DRAWER
                        else if (total > 120f) overlay = Overlay.SEARCH
                    },
                    onDragCancel = { total = 0f },
                    onVerticalDrag = { _, dy -> total += dy }
                )
            }
            .pointerInput(Unit) {
                detectTapGestures(onLongPress = { overlay = Overlay.SETTINGS })
            }
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            HorizontalPager(state = pager, modifier = Modifier.weight(1f)) { page ->
                when (page) {
                    0 -> TodayPage(vm, onLaunch, onLongPress)
                    libraryPage -> AppLibraryPage(
                        vm, onLaunch, onLongPress,
                        onSearch = { overlay = Overlay.SEARCH }
                    )
                    else -> HomeGridPage(vm, page - 1, perPage, onLaunch, onLongPress)
                }
            }
            PageDots(pageCount, pager.currentPage)
            AnimatedVisibility(visible = pager.currentPage in 1..homePages) {
                Dock(vm, onLaunch, onLongPress)
            }
        }

        if (s.edgePanelEnabled && overlay == Overlay.NONE) {
            EdgeHandle(onOpen = { edgeOpen = true }, modifier = Modifier.align(Alignment.CenterEnd))
        }

        AnimatedVisibility(
            visible = edgeOpen,
            enter = slideInHorizontally { it } + fadeIn(),
            exit = slideOutHorizontally { it } + fadeOut()
        ) {
            EdgePanel(vm, onLaunch, onLongPress, onClose = { edgeOpen = false })
        }

        AnimatedVisibility(
            visible = overlay == Overlay.DRAWER,
            enter = slideInVertically { it / 2 } + fadeIn(),
            exit = slideOutVertically { it / 2 } + fadeOut()
        ) {
            AppDrawer(
                vm, onLaunch, onLongPress,
                onClose = { overlay = Overlay.NONE },
                onSearch = { overlay = Overlay.SEARCH },
                onSettings = { overlay = Overlay.SETTINGS }
            )
        }

        AnimatedVisibility(
            visible = overlay == Overlay.SEARCH,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            SearchOverlay(vm, onLaunch, onLongPress, onClose = { overlay = Overlay.NONE })
        }

        AnimatedVisibility(
            visible = overlay == Overlay.SETTINGS,
            enter = slideInVertically { it / 3 } + fadeIn(),
            exit = slideOutVertically { it / 3 } + fadeOut()
        ) {
            SettingsScreen(vm, onClose = { overlay = Overlay.NONE })
        }

        menuApp?.let { app ->
            AppContextMenu(app, vm, onDismiss = { menuApp = null })
        }
    }
}

@Composable
private fun HomeGridPage(
    vm: LauncherViewModel,
    pageIndex: Int,
    perPage: Int,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit
) {
    val s = vm.settings
    val items = vm.homeApps.drop(pageIndex * perPage).take(perPage)

    Column(Modifier.fillMaxSize().padding(horizontal = 8.dp, vertical = 12.dp)) {
        for (r in 0 until s.rows) {
            Row(Modifier.weight(1f).fillMaxWidth()) {
                for (c in 0 until s.columns) {
                    val app = items.getOrNull(r * s.columns + c)
                    Box(
                        Modifier.weight(1f).fillMaxHeight(),
                        contentAlignment = Alignment.Center
                    ) {
                        if (app != null) {
                            AppCell(app, vm, { onLaunch(app) }, { onLongPress(app) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Dock(
    vm: LauncherViewModel,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit
) {
    val s = vm.settings
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(32.dp))
            .background(HomeSurface)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        vm.dockApps.forEach { app ->
            AppIcon(
                app, vm,
                Modifier
                    .size((58 * s.iconScale).dp)
                    .appClickable(vm, { onLaunch(app) }, { onLongPress(app) })
            )
        }
        if (vm.dockApps.isEmpty()) {
            Text(
                "Long-press an app and choose “Add to Dock”",
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 13.sp,
                modifier = Modifier.padding(vertical = 18.dp)
            )
        }
    }
}
