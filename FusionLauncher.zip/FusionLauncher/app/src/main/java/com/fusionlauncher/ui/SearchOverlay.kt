package com.fusionlauncher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fusionlauncher.LauncherViewModel
import com.fusionlauncher.data.AppInfo

/** iOS Spotlight style search: type to filter apps, or fall back to a web search. */
@Composable
fun SearchOverlay(
    vm: LauncherViewModel,
    onLaunch: (AppInfo) -> Unit,
    onLongPress: (AppInfo) -> Unit,
    onClose: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current

    LaunchedEffect(Unit) {
        focus.requestFocus()
        keyboard?.show()
    }

    val results = remember(query, vm.visibleApps) { vm.search(query) }
    val list = if (query.isBlank()) vm.suggestions else results

    fun submit() {
        when {
            query.isBlank() -> Unit
            results.isNotEmpty() -> onLaunch(results.first())
            else -> {
                vm.webSearch(query.trim())
                onClose()
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Glass.panel)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text("Search apps or the web") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    shape = RoundedCornerShape(24.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { submit() }),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Glass.field,
                        unfocusedContainerColor = Glass.field,
                        focusedTextColor = Glass.text,
                        unfocusedTextColor = Glass.text,
                        focusedPlaceholderColor = Glass.subtext,
                        unfocusedPlaceholderColor = Glass.subtext,
                        focusedLeadingIconColor = Glass.subtext,
                        unfocusedLeadingIconColor = Glass.subtext,
                        focusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent,
                        unfocusedIndicatorColor = androidx.compose.ui.graphics.Color.Transparent
                    ),
                    modifier = Modifier.weight(1f).focusRequester(focus)
                )
                TextButton(onClick = onClose) { Text("Cancel") }
            }

            LazyColumn(Modifier.fillMaxSize().padding(top = 12.dp)) {
                if (query.isBlank()) {
                    item {
                        Text(
                            if (list.isEmpty()) "Start typing to find an app." else "Suggestions",
                            color = Glass.subtext,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                }
                items(list, key = { it.packageName }) { app ->
                    ResultRow(app, vm, onClick = { onLaunch(app) }, onLongClick = { onLongPress(app) })
                }
                if (query.isNotBlank()) {
                    item {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    vm.webSearch(query.trim())
                                    onClose()
                                }
                                .padding(vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Search,
                                contentDescription = null,
                                tint = Glass.subtext,
                                modifier = Modifier.size(44.dp).padding(10.dp)
                            )
                            Spacer(Modifier.width(12.dp))
                            Text("Search the web for \"${query.trim()}\"", color = Glass.text)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultRow(
    app: AppInfo,
    vm: LauncherViewModel,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .appClickable(vm, onClick, onLongClick)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AppIcon(app, vm, Modifier.size(44.dp))
        Spacer(Modifier.width(12.dp))
        Text(app.label, color = Glass.text, fontSize = 16.sp)
    }
}
