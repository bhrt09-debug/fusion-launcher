package com.fusionlauncher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fusionlauncher.LauncherViewModel
import com.fusionlauncher.data.IconShape
import com.fusionlauncher.data.ThemeMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: LauncherViewModel, onClose: () -> Unit) {
    val s = vm.settings

    Column(
        Modifier
            .fillMaxSize()
            .background(Glass.panel)
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Launcher settings",
                color = Glass.text,
                fontSize = 22.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = Glass.text)
            }
        }

        Section("Home grid")
        Stepper("Columns", s.columns, 3, 6) { vm.updateSettings(s.copy(columns = it)) }
        Stepper("Rows", s.rows, 4, 8) { vm.updateSettings(s.copy(rows = it)) }

        Section("Icons")
        Text("Icon size", color = Glass.text)
        Slider(
            value = s.iconScale,
            onValueChange = { vm.updateSettings(s.copy(iconScale = it)) },
            valueRange = 0.8f..1.25f
        )
        SwitchRow("Show app names", s.showLabels) { vm.updateSettings(s.copy(showLabels = it)) }
        Text("Icon shape", color = Glass.text, modifier = Modifier.padding(top = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            IconShape.values().forEach { shape ->
                FilterChip(
                    selected = s.iconShape == shape,
                    onClick = { vm.updateSettings(s.copy(iconShape = shape)) },
                    label = { Text(shape.title) }
                )
            }
        }

        Section("Appearance")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ThemeMode.values().forEach { mode ->
                FilterChip(
                    selected = s.themeMode == mode,
                    onClick = { vm.updateSettings(s.copy(themeMode = mode)) },
                    label = { Text(mode.title) }
                )
            }
        }

        Section("Gestures & panels")
        SwitchRow("Edge panel (right edge handle)", s.edgePanelEnabled) {
            vm.updateSettings(s.copy(edgePanelEnabled = it))
        }
        SwitchRow("Haptic feedback", s.haptics) { vm.updateSettings(s.copy(haptics = it)) }
        Text(
            "Swipe up: app drawer  •  Swipe down: search  •  Swipe right: Today view  •  " +
                "Swipe to the last page: App Library  •  Long-press empty space: these settings",
            color = Glass.subtext,
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 8.dp)
        )

        Section("Hidden apps")
        if (vm.hiddenApps.isEmpty()) {
            Text("No hidden apps.", color = Glass.subtext)
        }
        vm.hiddenApps.forEach { app ->
            Row(
                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AppIcon(app, vm, Modifier.size(36.dp))
                Spacer(Modifier.width(12.dp))
                Text(app.label, color = Glass.text, modifier = Modifier.weight(1f))
                TextButton(onClick = { vm.unhide(app.packageName) }) { Text("Unhide") }
            }
        }

        Section("System")
        Button(onClick = { vm.openHomeSettings() }) { Text("Set as default launcher") }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun Section(title: String) {
    Text(
        title.uppercase(),
        color = Glass.subtext,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)
    )
}

@Composable
private fun Stepper(label: String, value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Glass.text, modifier = Modifier.weight(1f))
        TextButton(onClick = { if (value > min) onChange(value - 1) }) { Text("−", fontSize = 20.sp) }
        Text(value.toString(), color = Glass.text, fontSize = 16.sp)
        TextButton(onClick = { if (value < max) onChange(value + 1) }) { Text("+", fontSize = 20.sp) }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Glass.text, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
