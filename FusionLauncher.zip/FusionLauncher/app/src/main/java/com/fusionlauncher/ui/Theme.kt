package com.fusionlauncher.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.fusionlauncher.data.ThemeMode

val LocalDark = compositionLocalOf { true }

/** Translucent dark surface used on the home screen, over any wallpaper (dock, cards, folders). */
val HomeSurface = Color(0x59000000)

/** Full-screen overlay surfaces (drawer, search, settings, menus) that follow light/dark mode. */
object Glass {
    val panel: Color
        @Composable get() = if (LocalDark.current) Color(0xF01C1C1E) else Color(0xF0F2F2F7)
    val field: Color
        @Composable get() = if (LocalDark.current) Color(0xFF2C2C2E) else Color(0xFFE3E3E8)
    val text: Color
        @Composable get() = if (LocalDark.current) Color.White else Color(0xFF111111)
    val subtext: Color
        @Composable get() = if (LocalDark.current) Color(0xFFAEAEB2) else Color(0xFF6C6C70)
}

@Composable
fun FusionTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    CompositionLocalProvider(LocalDark provides dark) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
