package com.fusionlauncher.ui

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.BatteryManager
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fusionlauncher.LauncherViewModel
import com.fusionlauncher.data.AppInfo
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/** iOS "Today View": clock, quick widgets and Siri-style app suggestions. */
@Composable
fun TodayPage(vm: LauncherViewModel, onLaunch: (AppInfo) -> Unit, onLongPress: (AppInfo) -> Unit) {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var battery by remember { mutableIntStateOf(-1) }

    LaunchedEffect(Unit) {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        while (true) {
            now = LocalDateTime.now()
            battery = runCatching { bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) }
                .getOrDefault(-1)
            delay(15_000)
        }
    }

    val camManager = remember { ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager }
    var torchOn by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp)
    ) {
        Text(
            now.format(DateTimeFormatter.ofPattern("h:mm")),
            color = Color.White,
            fontSize = 72.sp,
            fontWeight = FontWeight.Light
        )
        Text(
            now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM")),
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 18.sp
        )
        Spacer(Modifier.height(20.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            WidgetCard(Modifier.weight(1f), onClick = null) {
                Text("Battery", color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
                Text(
                    if (battery >= 0) "$battery%" else "--",
                    color = Color.White,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
            WidgetCard(
                Modifier.weight(1f),
                onClick = {
                    runCatching {
                        val id = camManager.cameraIdList.first {
                            camManager.getCameraCharacteristics(it)
                                .get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                        }
                        val next = !torchOn
                        camManager.setTorchMode(id, next)
                        torchOn = next
                    }
                }
            ) {
                Text("Flashlight", color = Color.White.copy(alpha = 0.75f), fontSize = 13.sp)
                Text(
                    if (torchOn) "On" else "Off",
                    color = Color.White,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("Suggestions", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))

        val list = vm.suggestions
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(HomeSurface)
                .padding(12.dp)
        ) {
            if (list.isEmpty()) {
                Text(
                    "Apps you open most often will show up here.",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 14.sp
                )
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    list.chunked(4).forEach { rowApps ->
                        Row(Modifier.fillMaxWidth()) {
                            for (i in 0 until 4) {
                                val app = rowApps.getOrNull(i)
                                Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                                    if (app != null) {
                                        AppCell(app, vm, { onLaunch(app) }, { onLongPress(app) })
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WidgetCard(
    modifier: Modifier,
    onClick: (() -> Unit)?,
    content: @Composable () -> Unit
) {
    Column(
        modifier
            .clip(RoundedCornerShape(24.dp))
            .background(HomeSurface)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(16.dp)
    ) {
        content()
    }
}
